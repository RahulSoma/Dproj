﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Net;
using System.Data;
using System.Diagnostics;
using Excel = Microsoft.Office.Interop.Excel;

namespace DailyAlarmProj
{
    /// <summary>
    /// Interaction logic for DailyAlarm.xaml
    /// </summary>
    public partial class DailyAlarm : Window
    {
        public DailyAlarm()
        {
            InitializeComponent();
        }

        private void btnProcess_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("Reading Data from HTML", "Step 1", MessageBoxButton.OK, MessageBoxImage.Information);
            //bFirstStep.Background = Brushes.DeepSkyBlue;
            //bFirstStep.IsEnabled = true;
            //MessageBox.Show("Applying Filter Conditions", "Step 2", MessageBoxButton.OK, MessageBoxImage.Information);
            //bSecondStep.Background = Brushes.OrangeRed;
            //bSecondStep.IsEnabled = true;
            //MessageBox.Show("Processing The Message Count", "Step 3", MessageBoxButton.OK, MessageBoxImage.Information);
            //bThirdStep.Background = Brushes.HotPink;
            //bThirdStep.IsEnabled = true;
            //MessageBox.Show("Exporting Data to Excel", "Step 4", MessageBoxButton.OK, MessageBoxImage.Information);
            //bFourthStep.Background = Brushes.Purple;
            //bFourthStep.IsEnabled = true;
            //MessageBox.Show("Excel Generated Successfully", "Step 5", MessageBoxButton.OK, MessageBoxImage.Information);
            //bFifthStep.Background = Brushes.LawnGreen;
            //bFifthStep.IsEnabled = true;

            try
            {
                btnProcess.IsEnabled = false;
                ProcessData();
                MessageBox.Show("Excel generated successfully", "Excel Generated", MessageBoxButton.OK, MessageBoxImage.Information);
                btnProcess.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ProcessData()
        {
            string fileName;
            fileName = @"C:\Data\Rahul Data\Data\Desktop\20160129DailyAlarms.htm";

            //bFirstStep.Background = Brushes.DeepSkyBlue;
            //bFirstStep.IsEnabled = true;

            string text = File.ReadAllText(fileName);
            WebClient client = new WebClient();
            string html = client.DownloadString(fileName);
            DataTable dt = new DataTable();
            dt = HTMLParser.ParseTable(text);

            //bSecondStep.Background = Brushes.OrangeRed;
            //bSecondStep.IsEnabled = true;

            string filter = " column1 <> '1' and ((column3 not like '%_ALM_LL') and (column3 not like '%_ALM_HH')) and column4 like '%Process%'";
            DataTable dtFilter = new DataTable();

            dt.DefaultView.RowFilter = filter;
            dtFilter = dt.DefaultView.ToTable();

            //bThirdStep.Background = Brushes.HotPink;
            //bThirdStep.IsEnabled = true;

            string str = string.Empty;
            string count = string.Empty;

            var result = dtFilter.AsEnumerable()
                            .GroupBy(r => r.Field<string>("Column6"))
                            .Select(row => new
                            {
                                str = row.Key,
                                count = row.Count()
                            });

            DataTable dtExport = new DataTable();
            dtExport.Columns.Add("Message", typeof(string));
            dtExport.Columns.Add("Count", typeof(string));

            foreach (var item in result)
            {
                DataRow dr = dtExport.NewRow();

                dr["Message"] = item.str;
                dr["Count"] = item.count;

                dtExport.Rows.Add(dr);
            }

            //bFourthStep.Background = Brushes.Purple;
            //bFourthStep.IsEnabled = true;

            exportToExcel(dtExport);

            //bFifthStep.Background = Brushes.LawnGreen;
            //bFifthStep.IsEnabled = true;

        }

        private void exportToExcel(System.Data.DataTable dt)
        {

            /*Set up work book, work sheets, and excel application*/
            Microsoft.Office.Interop.Excel.Application oexcel = new Microsoft.Office.Interop.Excel.Application();
            try
            {
                string path = AppDomain.CurrentDomain.BaseDirectory;
                object misValue = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Excel.Workbook obook = oexcel.Workbooks.Add(misValue);
                Microsoft.Office.Interop.Excel.Worksheet osheet = new Microsoft.Office.Interop.Excel.Worksheet();


                //  obook.Worksheets.Add(misValue);

                osheet = (Microsoft.Office.Interop.Excel.Worksheet)obook.Sheets["Sheet1"];
                int colIndex = 0;
                int rowIndex = 1;

                foreach (DataColumn dc in dt.Columns)
                {
                    colIndex++;
                    osheet.Cells[1, colIndex] = dc.ColumnName;
                }
                foreach (DataRow dr in dt.Rows)
                {
                    rowIndex++;
                    colIndex = 0;

                    foreach (DataColumn dc in dt.Columns)
                    {
                        colIndex++;
                        osheet.Cells[rowIndex, colIndex] = dr[dc.ColumnName];
                    }
                }

                //osheet.Columns.AutoFit();
                osheet.Columns["A:B"].AutoFit();
                string filepath = @"C:\Data\Rahul Data\Data\Desktop\ExcelOutput\Output";

                //Release and terminate excel

                obook.SaveAs(filepath);
                obook.Close();
                oexcel.Quit();
                releaseObject(osheet);
                releaseObject(obook);
                releaseObject(oexcel);
                GC.Collect();
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(oexcel);

                Process[] excelProcesses = Process.GetProcessesByName("excel");
                foreach (Process p in excelProcesses)
                {
                    if (string.IsNullOrEmpty(p.MainWindowTitle)) // use MainWindowTitle to distinguish this excel process with other excel processes 
                    {
                        p.Kill();
                    }
                }
            }
            catch (Exception)
            {
                oexcel.Quit();
            }
            finally
            {
            }
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
